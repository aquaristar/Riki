javac *.java -d bin
java -cp bin tetris.Tetris